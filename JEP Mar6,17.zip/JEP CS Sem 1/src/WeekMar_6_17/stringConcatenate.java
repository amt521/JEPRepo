package WeekMar_6_17;

public class stringConcatenate {
	public static void main(String[] args) {
		String firstName = "Tommy";
		String lastName = "Trojan";
		String fullName = firstName + " " + lastName;
		System.out.println(fullName);
		// On the console you would see: Tommy Trojan
	}
}
