package WeekMar_6_17;

public class rocketLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 0; i >= 0; i--) {
			String rocketname = "Apollo";
			System.out.println("Apollo launching in: " + i);
		}
		System.out.println("Blastoff!!!!!!!!");

	}

}
